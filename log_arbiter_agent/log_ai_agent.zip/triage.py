#!/usr/bin/env python3
import argparse, os, json, numpy as np, pandas as pd, re, os
from typing import Dict, Any
from utils import load_pickle
from sklearn.metrics.pairwise import cosine_similarity

def top_match(vec, X, k=3):
    sims = cosine_similarity(vec, X).ravel()
    idx = sims.argsort()[::-1][:k]
    return list(zip(idx, sims[idx]))

def decide(row: Dict[str, Any], kb_idx, ig_idx, t_known=0.40, t_ignore=0.42):
    # Encode incident with TF-IDF (char ngrams) fit spaces
    text = row['log_window']
    kb_vec = kb_idx['vec'].transform([text])
    ig_vec = ig_idx['vec'].transform([text])

    kbest = top_match(kb_vec, kb_idx['X'], k=3)
    ibest = top_match(ig_vec, ig_idx['X'], k=3)

    # Check regex rules (if present)
    rule_hit = None
    for i, rec in kb_idx['df'].iterrows():
        pass  # no rules for known

    for i, rec in ig_idx['df'].iterrows():
        rx = rec.get('rule_regex') if 'rule_regex' in ig_idx['df'].columns else ""
        if isinstance(rx, str) and rx:
            try:
                if re.search(rx, text, re.I):
                    rule_hit = dict(pattern_id=rec.get('pattern_id', f'IGN-{i}'), rule_regex=rx)
                    break
            except re.error:
                pass

    # Decision logic (simple, deterministic; you can add LLM arbitration later)
    # 1) If strong ignore regex → 0
    if rule_hit:
        return dict(label=0, confidence=0.95, reason=f"ignore-rule:{rule_hit['pattern_id']}", evidence=[rule_hit['rule_regex']])

    # 2) Otherwise compare similarities
    k0_idx, k0_sim = (kbest[0] if kbest else (-1, 0.0))
    i0_idx, i0_sim = (ibest[0] if ibest else (-1, 0.0))

    if k0_sim >= max(t_known, i0_sim + 0.05):
        bug = kb_idx['df'].iloc[k0_idx].to_dict()
        return dict(label=1, confidence=float(k0_sim), reason="known-match", evidence=[bug.get('bug_id','')])

    if i0_sim >= t_ignore:
        ign = ig_idx['df'].iloc[i0_idx].to_dict()
        return dict(label=0, confidence=float(i0_sim), reason="ignore-match", evidence=[ign.get('pattern_id','')])

    # 3) Otherwise, needs triage (-1)
    return dict(label=-1, confidence=float(1 - max(k0_sim, i0_sim)), reason="novel-or-ambiguous", evidence=[])

def main(incidents_path: str, known_idx_path: str, ignore_idx_path: str, outdir: str):
    kb_idx = load_pickle(known_idx_path)
    ig_idx = load_pickle(ignore_idx_path)

    df = pd.read_csv(incidents_path)
    os.makedirs(outdir, exist_ok=True)

    outs = {1: [], 0: [], -1: []}
    rows = []
    for _, r in df.iterrows():
        decision = decide(r, kb_idx, ig_idx)
        rec = dict(
            incident_id=r['incident_id'],
            host=r.get('host',''),
            component=r.get('component',''),
            start_time=r.get('start_time',''),
            end_time=r.get('end_time',''),
            label=int(decision['label']),
            confidence=round(decision['confidence'], 4),
            reason=decision['reason'],
            evidence=";".join(decision['evidence'])
        )
        rows.append(rec)
        outs[int(decision['label'])].append(rec)

    # write jsonl
    for lab, items in outs.items():
        with open(os.path.join(outdir, f"label_{lab}.jsonl"), "w") as f:
            for it in items:
                f.write(json.dumps(it) + "\n")

    # write combined csv
    pd.DataFrame(rows).to_csv(os.path.join(outdir, "triage_all.csv"), index=False)
    print(f"Done. Wrote {sum(len(v) for v in outs.values())} decisions into {outdir}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--incidents", required=True)
    ap.add_argument("--known-index", required=True)
    ap.add_argument("--ignore-index", required=True)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()
    main(args.incidents, args.known_index, args.ignore_index, args.outdir)
