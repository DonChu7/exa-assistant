#!/usr/bin/env python3
import argparse, os, pickle, pandas as pd, numpy as np
from typing import List, Dict, Any
from utils import dump_pickle
from sklearn.feature_extraction.text import TfidfVectorizer

EMB_PATH_KNOWN = "data/.known_index.pkl"
EMB_PATH_IGNORE = "data/.ignore_index.pkl"

def vectorize_texts(texts: List[str]):
    vec = TfidfVectorizer(min_df=1, ngram_range=(3,5), analyzer='char_wb')
    X = vec.fit_transform(texts)
    return vec, X

def main(known_path: str, ignore_path: str):
    os.makedirs("data", exist_ok=True)

    # Known bugs
    kb = pd.read_csv(known_path)
    kb.fillna("", inplace=True)
    kb_texts = kb['context_window'].astype(str).tolist()
    kb_vec, kb_X = vectorize_texts(kb_texts)
    dump_pickle(dict(df=kb, vec=kb_vec, X=kb_X), EMB_PATH_KNOWN)
    print(f"Built known-bugs index: {EMB_PATH_KNOWN} (n={kb_X.shape[0]})")

    # Ignorable
    ig = pd.read_csv(ignore_path)
    ig.fillna("", inplace=True)
    ig_texts = ig['context_window'].astype(str).tolist()
    ig_vec, ig_X = vectorize_texts(ig_texts)
    dump_pickle(dict(df=ig, vec=ig_vec, X=ig_X), EMB_PATH_IGNORE)
    print(f"Built ignorable index: {EMB_PATH_IGNORE} (n={ig_X.shape[0]})")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--known", required=True)
    ap.add_argument("--ignore", required=True)
    args = ap.parse_args()
    main(args.known, args.ignore)
